﻿namespace Villa_MVC.Models
{
    public enum APIType
    {
        GET,
        POST,
        PUT,
        DELETE
    }
}
