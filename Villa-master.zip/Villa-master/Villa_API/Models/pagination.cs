﻿namespace Villa_API.Models
{
    public class Pagination
    {
       public int PageSize { get; set; }
       public int PageNumber { get; set; }
    }
}
